export const CollectionsTemplate = (db, DataTypes) => {
    return db.define("colection", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false
        }
    },
        {
            underscored: true
        })
};