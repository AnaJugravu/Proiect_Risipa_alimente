import { Collection } from "../models/config.js";

export const create = async (collection) => {
    return await Collection.create(collection);
};