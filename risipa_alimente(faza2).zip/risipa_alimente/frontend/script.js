function loadAlimente() {
    fetch("http://localhost:8080/api/alimente")
        .then(response => response.json())
        .then(data => data.alimente)
        .then(alimente => {
            const alimentList = document.getElementById("alimenteContainer");
            alimentList.innerHTML = "";

            for(let aliment of alimente) {
                const item = document.createElement("div");
                item.classList.add("alimente-container");
                item.addEventListener("click", () => onAlimentClick(aliment));

                const alimentDen = document.createElement("p");
                alimentDen.innerText = aliment.denumire;

                item.appendChild(alimentDen);

                alimentList.appendChild(item);
            }
        });
}

function onAlimentClick(aliment) {
    alert("Producator: " + aliment.producator);
}