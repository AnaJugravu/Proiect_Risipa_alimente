import * as usersService from "../services/users.js";

const getUsers = async (req, res) => {
    res.send({ users: await usersService.getUsers(req.query) });
};

const getById = async (req, res) => {
    const identifiedUser = await usersService.getById(req.params.id);

    if (!!identifiedUser) {
        res.send({ user: identifiedUser });
    } else {
        res.status(404).send();
    }
};

/*const create = async (req, res) => {
    if (!req.body.denumire || !req.body.dataExpirare || !req.body.categorie || !req.body.producator || !req.body.stocDisponibil || !req.body.pret) {
        return res.status(404).send({ message: "Missing elements" });
    }

    await usersService.create(req.body);
    res.status(201).send();
};

const update = async (req, res) => {
    if (!req.body.id) {
        return res.status(400).send({ message: "Id is mandatory" });
    }

    await usersService.update(req.body);
    res.status(204).send();
}

const remove = (req, res) => {
    usersService.remove(req.params.id);
    res.send();
}

export {
    getUsers,
    getById,
    create,
    update,
    remove
}*/