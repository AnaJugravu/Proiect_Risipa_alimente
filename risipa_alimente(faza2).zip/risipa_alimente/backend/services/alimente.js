import { Op } from "sequelize";
import { Aliment } from "../models/config.js";

export const getAliment = async (query) => {
    delete query.id;

    const where = Object.keys(query).map(key => {
        if (key === "denumire") {
            return { [key]: { [Op.like]: `%${query[key]}%` } }
        }

        return { [key]: query[key] }
    });

    return await Aliment.findAll({
        attributes: ['id', 'denumire', 'dataExpirare', 'categorie', 'producator', 'stocDisponibil', 'pret'],
        where: where
    });
};

export const getById = async (id) => {
    return await Aliment.findOne({
        where: {
            id: id
        }
    });
};

export const create = async (aliment) => {
    return await Aliment.create(aliment);
};

export const update = async (alimentUpdateData) => {
    const aliment = await Aliment.findOne({
        where: {
            id: alimentUpdateData.id
        }
    });

    if (!!aliment) {
        delete alimentUpdateData.id;
        aliment.set({
            ...alimentUpdateData
        });

        await aliment.save();
    }
}

export const remove = (id) => {
    Aliment.destroy({
        where: {
            id: id
        }
    });
}