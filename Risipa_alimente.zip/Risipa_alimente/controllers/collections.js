import * as collectionsService from "../services/collections.js";

const create = async (req, res) => {
    if (!req.body.name) {
        return res.status(404).send({ message: "Missing name" });
    }

    await collectionsService.create(req.body);
    res.status(201).send();
};

export {
    create
}