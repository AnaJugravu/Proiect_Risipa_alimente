import express from 'express';
import * as alimenteController from "../controllers/alimente.js";

export const router = express.Router();

router.get("/", alimenteController.getAlimente);
router.get("/:id", alimenteController.getById);

router.post("/", alimenteController.create);

router.patch("/", alimenteController.update);

router.delete("/:id", alimenteController.remove);
