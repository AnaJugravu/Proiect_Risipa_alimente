import express from 'express';

import {router as alimenteRouter} from './alimente.js';
import {router as collectionsRouter} from './collections.js';

export const router = express.Router();

router.use("/alimente", alimenteRouter);
router.use("/collections", collectionsRouter);