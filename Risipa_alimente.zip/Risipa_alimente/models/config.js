import { DataTypes, Sequelize } from "sequelize";
import { CollectionsTemplate } from "./collections.js";
import { AlimenteTemplate } from "./alimente.js";

export const db = new Sequelize({
   dialect: "sqlite",
   storage: "alimente.db"
});

export const Aliment = AlimenteTemplate(db, DataTypes);
export const Collection = CollectionsTemplate(db, DataTypes);

export const synchronizeDatabase = async () => {
   await db.authenticate();
   await db.sync();
};
